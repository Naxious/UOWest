/*
 * UltimeLive is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * UltimaLive is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with UltimaLive.  If not, see <http://www.gnu.org/licenses/>. 
 */


#ifndef _I_FILE_MANAGER_H
#define _I_FILE_MANAGER_H

#include <cstdio>
#include <fstream>
#include <Windows.h>
#include <map>
#include <string>
#include <stdio.h>
#include "ClientFileHandleSet.h"
#include "BaseFileManager.h"
#include "..\Utils.h"
#include "..\ProgressBarDialog.h"

class MapDefinition;
class LoginHandler;

/* The responsibility of the file manager is to handle the custom file formats that the client may employ. The main
 * reason for using a factory pattern here is because the client seems to be in a transistion phase where old
 * mul files are being converted to the new uop format.  The conversion has not happened all at once, so the factory
 * will allow the use of different file managers based on the client version.
 *
 * The file manager will redirect the client to open files from alternate folders, alter files that are on disk, 
 * create new map files, defragment files, and any other filesystem type tasks.
 */
class BaseFileManager
{
  public:
    BaseFileManager();

  virtual HANDLE WINAPI OnCreateFileA(
    __in      LPCSTR lpFileName,
    __in      DWORD dwDesiredAccess,
    __in      DWORD dwShareMode,
    __in_opt  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
    __in      DWORD dwCreationDisposition,
    __in      DWORD dwFlagsAndAttributes,
    __in_opt  HANDLE hTemplateFile
  );

  virtual LPVOID WINAPI OnMapViewOfFile(
    __in  HANDLE hFileMappingObject,
    __in  DWORD dwDesiredAccess,
    __in  DWORD dwFileOffsetHigh,
    __in  DWORD dwFileOffsetLow,
    __in  SIZE_T dwNumberOfBytesToMap
    );

  virtual HANDLE WINAPI OnCreateFileMappingA(
    __in      HANDLE hFile,
    __in_opt  LPSECURITY_ATTRIBUTES lpAttributes,
    __in      DWORD flProtect,
    __in      DWORD dwMaximumSizeHigh,
    __in      DWORD dwMaximumSizeLow,
    __in_opt  LPCSTR lpName
  );

  virtual BOOL WINAPI OnCloseHandle(_In_  HANDLE hObject);

  virtual bool updateLandBlock(uint8_t mapNumber, uint32_t blockNum, uint8_t* pData) = 0;
  virtual unsigned char* readLandBlock(uint8_t mapNumber, uint32_t blockNum) = 0;
  virtual unsigned char* readStaticsBlock(uint32_t mapNumber, uint32_t blockNum, uint32_t& rNumberOfBytesOut);
  virtual bool writeStaticsBlock(uint8_t mapNumber, uint32_t blockNum, uint8_t* pBlockData, uint32_t length);
  virtual void Initialize();
  virtual void LoadMap(uint8_t mapNumber) = 0;
  virtual void InitializeShardMaps(std::string shardIdentifier, std::map<uint32_t, MapDefinition> definitions);
  virtual void onLogout();

  static void copyFile(std::string sourceFilePath, std::string destFilePath, ProgressBarDialog* pProgress);

  static const int STATICS_MEMORY_SIZE = 200000000;

protected:
  std::map<std::string, ClientFileHandleSet*> m_files;
  uint8_t* m_pMapPool;
  uint8_t* m_pStaticsPool;
  uint8_t* m_pStaticsPoolEnd;
  uint8_t* m_pStaidxPool;
  uint8_t* m_pStaidxPoolEnd;
  std::string m_shardIdentifier;
  std::ofstream* m_pMapFileStream;
  std::ofstream* m_pStaidxFileStream;
  std::ofstream* m_pStaticsFileStream;
  std::string getUltimaLiveSavePath();
  virtual bool createNewPersistentMap(std::string pathWithoutFilename, uint8_t mapNumber, uint32_t numHorizontalBlocks, uint32_t numVerticalBlocks);

  ProgressBarDialog* m_pProgressDlg;

};
#endif