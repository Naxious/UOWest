/*
* UltimeLive is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* UltimaLive is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with UltimaLive.  If not, see <http://www.gnu.org/licenses/>. 
*/

#include "ProgressBarDialog.h"

BOOL CALLBACK ProgressBarDialog::DialogProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch(message)
  {
    case WM_INITDIALOG:
    {
    }
    break;

    default:
    {
      return false;
    }
  }
  return true;
}

HMODULE GetCurrentModuleHandle()
{
    HMODULE hMod = NULL;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
          reinterpret_cast<LPCWSTR>(&GetCurrentModuleHandle),
          &hMod);
     return hMod;
}

void ProgressBarDialog::setProgress(uint32_t progress)
{
  HWND hwndProgressBar = GetDlgItem(m_hDialog, IDC_PROGRESS1);
  SendMessage(hwndProgressBar, PBM_SETPOS, progress, 0);
}

ProgressBarDialog::ProgressBarDialog()
  : m_hDialog()
{
}

void ProgressBarDialog::setMessage(std::string message)
{
  HWND hwndProgressBarMessage = GetDlgItem(m_hDialog,  IDC_IMPORT_MESSAGE);
  SetWindowText(hwndProgressBarMessage, message.c_str());      
}

void ProgressBarDialog::show()
{
  m_hDialog = CreateDialog ((HINSTANCE)GetCurrentModuleHandle(), MAKEINTRESOURCE (IDD_DIALOG1), 0, ProgressBarDialog::DialogProc);
}

void ProgressBarDialog::hide()
{
  DestroyWindow(m_hDialog);
}