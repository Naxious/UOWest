#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_ICON1                               100
#define IDI_ICON2                               101
#define IDD_DIALOG1                             102
#define IDC_IMPORT_MESSAGE                      1000
#define IDC_PROGRESS1                           1002
