﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Server.Commands;
using System.IO;
using Server.Mobiles;
using System.Text.RegularExpressions;

namespace Server.Customs
{
    public static class SimpleChat
    {
        private static Regex m_NickRegEx = new Regex(@"^\w{4,}$");
        private static string m_Path = Path.Combine("Saves", "SimpleChat.bin");
        private static Dictionary<string, string> m_Nicks = new Dictionary<string, string>();
        private static HashSet<string> m_Muted = new HashSet<string>();

        public static void Configure()
        {
            EventSink.WorldSave += EventSink_WorldSave;
            EventSink.WorldLoad += EventSink_WorldLoad;
        }

        public static void Initialize()
        {
            CommandSystem.Register("chat", AccessLevel.Player, new CommandEventHandler(Chat_OnCommand));
            CommandSystem.Register("ch", AccessLevel.Player, new CommandEventHandler(Chat_OnCommand));
            CommandSystem.Register("c", AccessLevel.Player, new CommandEventHandler(Chat_OnCommand));
            CommandSystem.Register("nick", AccessLevel.Player, new CommandEventHandler(Nick_OnCommand));
            CommandSystem.Register("mute", AccessLevel.Counselor, new CommandEventHandler(Mute_OnCommand));
        }

        private static void EventSink_WorldSave(WorldSaveEventArgs e)
        {
            Persistence.Serialize(
                m_Path,
                writer =>
                {
                    writer.Write(0); // Version

                    // Nick names
                    writer.Write(m_Nicks.Count);
                    foreach (string username in m_Nicks.Keys)
                    {
                        writer.Write(username);
                        writer.Write(m_Nicks[username]);
                    }

                    // Muted accounts
                    writer.Write(m_Muted.Count);
                    foreach (string username in m_Muted)
                    {
                        writer.Write(username);
                    }
                });
        }

        private static void EventSink_WorldLoad()
        {
            Persistence.Deserialize(
                m_Path,
                reader =>
                {
                    m_Nicks.Clear();
                    m_Muted.Clear();

                    int version = reader.ReadInt();
                    int count;

                    // Nick names
                    count = reader.ReadInt();
                    for (int i = 0; i < count; ++i)
                    {
                        m_Nicks[reader.ReadString()] = reader.ReadString();
                    }

                    // Muted accounts
                    count = reader.ReadInt();
                    for (int i = 0; i < count; ++i)
                    {
                        m_Muted.Add(reader.ReadString());
                    }
                });
        }

        [Usage("Chat [Message]")]
        [Description("Sends a global chat message")]
        private static void Chat_OnCommand(CommandEventArgs e)
        {
            if (!(e.Mobile is PlayerMobile))
                return;
            string username = e.Mobile.Account.Username;

            if (m_Muted.Contains(username))
            {
                e.Mobile.SendMessage(33, "You have been muted.");
                return;
            }

            if (!m_Nicks.ContainsKey(username))
            {
                e.Mobile.SendMessage(33, "You must first set your chat nickname with the [nick command.");
                return;
            }

            if (String.IsNullOrEmpty(e.ArgString))
                return;

            string nick = m_Nicks[username];
            int hue = 103;
            if (e.Mobile.AccessLevel >= AccessLevel.Counselor)
                hue = 112;
            if (e.Mobile.AccessLevel >= AccessLevel.GameMaster)
                hue = 33;
            World.Broadcast(hue, false, String.Format("{0}: {1}", nick, e.ArgString));
        }

        [Usage("Nick NickName")]
        [Description("Sets your account's nickname")]
        private static void Nick_OnCommand(CommandEventArgs e)
        {
            if (!(e.Mobile is PlayerMobile))
                return;
            string username = e.Mobile.Account.Username;

            if (String.IsNullOrEmpty(e.ArgString) ||
                e.Arguments.Length != 1)
            {
                e.Mobile.SendMessage(33, "Usage: Nick NickName");
                return;
            }

            string nick = e.Arguments[0];
            if (!m_NickRegEx.IsMatch(nick))
            {
                e.Mobile.SendMessage(33, "Nicknames must be at least four characters long and must only contain letters and numbers.");
                return;
            }
			
			if(m_Nicks.ContainsKey(username))
			{
				e.Mobile.SendMessage(33, "You have already set your nickname.");
				return;
			}

            if (m_Nicks.ContainsValue(nick))
            {
                e.Mobile.SendMessage(33, "That nickname is already in use.");
                return;
            }

            m_Nicks[username] = nick;
        }

        [Usage("Mute NickName")]
        [Description("Mutes or unmutes the given nickname")]
        private static void Mute_OnCommand(CommandEventArgs e)
        {
            if (!(e.Mobile is PlayerMobile))
                return;

            if(String.IsNullOrEmpty(e.ArgString) ||
                e.Arguments.Length != 1)
            {
                e.Mobile.SendMessage(33, "Usage: Mute NickName");
                return;
            }

            string nick = e.Arguments[0];
            string username = null;
            foreach (string key in m_Nicks.Keys)
            {
                if(m_Nicks[key] == nick)
                {
                    username = key;
                    break;
                }
            }
            if (username == null)
            {
                e.Mobile.SendMessage(33, "No user account with that nickname was found.");
                return;
            }

            if (m_Muted.Contains(username))
            {
                m_Muted.Remove(username);
                e.Mobile.SendMessage("The account has been unmuted.");
            }
            else
            {
                m_Muted.Add(username);
                e.Mobile.SendMessage("The account has been muted.");
            }
        }
    }
}
