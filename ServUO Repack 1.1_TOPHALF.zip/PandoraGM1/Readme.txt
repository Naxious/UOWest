If you have any bug to report, please open a new issue to http://code.google.com/p/pandorasbox3/issues/list or if you are not
comfortable with it send me an email at smjert30@libero.it, thanks.

The pb3 team.
