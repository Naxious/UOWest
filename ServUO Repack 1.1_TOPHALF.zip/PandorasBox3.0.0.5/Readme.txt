This version of Pandora is an alpha, we didn't make any substantial modification, 
only code cleanup, updates and little performance tweaks.
However we are going to change things more visible about Pandora.
We will not release Pandora with installer, unless some parts of Pandora requires it.
Last but not least BoxServer isn't working, so we didn't include BoxServerSetup, anyway its controls are still included in Pandora's exe
however we strongly advice you to not use it.

If have any bug to report, please open a new issue to http://code.google.com/p/pandorasbox3/issues/list or if you are not
comfortable with it send me an email at smjert30@libero.it, thanks.

The pb3 team.
